<?php defined('_JEXEC') or die('Restricted access');

/* Module chrome for rendering the module in a slider
************************************************************/
function modChrome_slider($module, &$params, &$attribs)
{
	jimport('joomla.html.pane');
	// Initialize variables
	$sliders = & JPane::getInstance('sliders');
	$sliders->startPanel( JText::_( $module->title ), 'module' . $module->id );
	echo $module->content;
	$sliders->endPanel();
}

/* Module chrome for rendering the module in a custom style
************************************************************/
function modChrome_custom($module, &$params, &$attribs)
{
?>
	<div class="moduletable">
		<h3><?php echo JText::_( $module->title ); ?></h3>
		<?php echo $module->content; ?>
	</div>
	<div class="moduletablebottom"></div>
<?php
}
?>