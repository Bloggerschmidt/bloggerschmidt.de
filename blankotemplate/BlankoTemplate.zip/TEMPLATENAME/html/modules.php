<?php defined('_JEXEC') or die('Restricted access');

function modChrome_slider($module, &$params, &$attribs) {
	jimport('joomla.html.pane');
	// Initialize variables
	$sliders = & JPane::getInstance('sliders');
	$sliders->startPanel(JText::_($module->title),'module'.$module->id);
	echo $module->content;
	$sliders->endPanel();
}

function modChrome_wpstyle($module, &$params, &$attribs) { 
	?>
	<div class="wp_top"></div>
	<div class="wp_module">
		<h3><?php echo JText::_( $module->title ); ?></h3>
		<?php echo $module->content; ?>
	</div>
	<div class="wp_bottom"></div>
	<?php
} 
?>
